---
name: Bug report
about: Create a report to help us improve

---

### What I'm trying to achieve
…

### Steps to reproduce the problem
1. 
2. 

### What I expected to happen
…

### Screenshots
<!-- If applicable, add screenshots to help explain your problem. -->

**System information**
Operating system: 
Browser:
