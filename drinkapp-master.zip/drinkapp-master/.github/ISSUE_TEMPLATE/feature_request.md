---
name: Feature request
about: Suggest an idea for this project

---

### What I'm trying to achieve
…

### Describe a proposed solution
...

### Other solutions I've tried and won't work
…

### Screenshots or mockups
<!-- Please provide any illustrations that could help others understand the problem or the proposed solution. -->
