Customizing Templates
=====================

Default storefront templates are based on `Bootstrap 4 <https://v4-alpha.getbootstrap.com/>`_.

You can find the files under ``/templates/``.
