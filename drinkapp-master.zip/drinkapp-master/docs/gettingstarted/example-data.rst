Example Data
============

If you'd like some data to test your new storefront you can populate the database with example products and orders:

.. code-block:: console

 $ python manage.py populatedb
